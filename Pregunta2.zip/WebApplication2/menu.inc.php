<link rel="stylesheet" type="text/css" href="./estilo.css">
<div id="menu">
		<lu>
		
			<li><a href="./Quimica/quimica.php">Quimica</a></li>
	    	<li><a href="./Fisica/fisica.php">Fisica</a></li>
          <li><a href="./Informatica/inf.php">Informatica</a></li>
		</lu>		
	</div>