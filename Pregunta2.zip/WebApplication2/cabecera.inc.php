<!DOCTYPE html>
<html>
<head>
	<title>Ejemplo Maquetado</title>
	<link rel="stylesheet" type="text/css" href="./estilo.css">
</head>
<body>
	<div class="cabecera">
		<h1 style="font-size: 12px;font-family: arial"><center>Universidad Mayor de San Andres</center></h1><br>
		<h2 style="font-size: 12px; font-family: arial"><center>Facultad de Ciencias Puras y Naturales</center></h2>
	</div>
	      <!-- end loader -->
      <!-- header -->