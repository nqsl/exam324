<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Model {
	public function __construct()
	{
		$this->load->database;
	}
	public function lista_persona()
	{
		return $this->db->get("persona")->row_array();
	}	
}
