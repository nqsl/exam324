<link rel="stylesheet" type="text/css" href="./estilo.css">
<div class="cuerpo">
   <p>La Faculta de Ciencias Puras y Naturales fue fundada hace casi 50 años, ya tiene muchos años de existencia ...</p>