<?php
$con = mysqli_connect("localhost","Usuario","12345");
mysqli_select_db($con,"BDATOS");
?>