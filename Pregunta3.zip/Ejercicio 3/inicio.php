
<?php include 'header.php'; ?>

<?php include 'hero.php'; ?>

<?php include 'footer.php'; ?>