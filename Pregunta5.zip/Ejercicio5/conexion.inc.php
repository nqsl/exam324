<?php
     $con = mysqli_connect("localhost","director","123456");
     mysqli_select_db($con,"mibasericardo");
?>